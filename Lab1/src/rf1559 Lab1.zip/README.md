#Lab 1 - Ross Freeman
This Java program consists of 3 files with Lab1.java containing the main method. It should be compiled using "javac Lab1.java" and it can be run by using "java Lab1 fileLoc". When running, it expects to receive the input file name as a command line arguement (fileLoc in the above command).
